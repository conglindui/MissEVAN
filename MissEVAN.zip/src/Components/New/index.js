import React,{Component} from "react";

class New extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			New组件
		</div>
	}
}

export default New;