import React,{Component} from "react";

class Footer extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div id="footer">
			footer组件
		</div>
	}
}

export default Footer;