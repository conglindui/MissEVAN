import React,{Component} from "react";

class Search extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			search组件
		</div>
	}
}

export default Search;