import React,{Component} from "react";

class Recommend extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			Recommend组件
		</div>
	}
}

export default Recommend;