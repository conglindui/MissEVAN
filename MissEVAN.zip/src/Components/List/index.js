import React,{Component} from "react";

class List extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			List组件
		</div>
	}
}

export default List;