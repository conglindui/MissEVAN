import React,{Component} from "react";

class Type extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			Type组件
		</div>
	}
}

export default Type;