import React,{Component} from "react";

class Reg extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			reg组件
		</div>
	}
}

export default Reg;