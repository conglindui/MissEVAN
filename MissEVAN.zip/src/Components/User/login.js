import React,{Component} from "react";

class Login extends Component{
	constructor(prop){
		super(prop);
	}


	render(){
		return <div>
			login组件
		</div>
	}
}

export default Login;